import logging
import os
from typing import Annotated

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from openai import AsyncOpenAI, APIConnectionError, APITimeoutError, APIStatusError
from pydantic import BaseModel, ConfigDict, Field, field_validator

logging.basicConfig(level=os.getenv("LOG_LEVEL", "INFO"))
logger = logging.getLogger("medexplain")

APP_VERSION = "1.1.0"
OPENAI_MODEL = os.getenv("OPENAI_MODEL", "gpt-4o-mini")
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
MAX_OUTPUT_TOKENS = int(os.getenv("MAX_OUTPUT_TOKENS", "700"))

app = FastAPI(title="MedExplain API", description="Educational medical explanations; not diagnosis or treatment.", version=APP_VERSION)

origins = [x.strip() for x in os.getenv("CORS_ORIGINS", "*").split(",") if x.strip()]
app.add_middleware(CORSMiddleware, allow_origins=origins or ["*"], allow_credentials=False, allow_methods=["GET", "POST"], allow_headers=["Content-Type"])


class ExplainRequest(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)
    question: Annotated[str, Field(min_length=3, max_length=1200)]

    @field_validator("question")
    @classmethod
    def nonblank(cls, value: str) -> str:
        if not value.strip():
            raise ValueError("Please enter a medical term or question.")
        return value


class ExplainResponse(BaseModel):
    explanation: str
    disclaimer: str = "Educational information only. Not a diagnosis or a substitute for advice from a qualified healthcare professional."
    model: str


@app.get("/")
async def home():
    return {"message": "MedExplain backend is running!", "version": APP_VERSION}


@app.get("/health")
async def health():
    return {"status": "healthy", "version": APP_VERSION, "ai_configured": bool(OPENAI_API_KEY)}


@app.post("/explain", response_model=ExplainResponse)
async def explain(payload: ExplainRequest):
    if not OPENAI_API_KEY:
        raise HTTPException(status_code=503, detail="AI service is not configured. Add OPENAI_API_KEY in the hosting environment.")

    client = AsyncOpenAI(api_key=OPENAI_API_KEY, timeout=30.0, max_retries=1)
    system_prompt = (
        "You are MedExplain, an educational medical-literacy assistant. Explain medical terms and general health concepts "
        "in clear, calm, plain language. Do not diagnose, interpret symptoms as a diagnosis, recommend medicines or dosages, "
        "prescribe treatment, or tell users to ignore professional care. If a user describes a possible emergency, advise "
        "urgent in-person help; in India call 112. Do not claim to read medical records or know facts not supplied. "
        "Avoid requesting identifying information. Keep answers concise and educational."
    )
    try:
        result = await client.chat.completions.create(
            model=OPENAI_MODEL,
            messages=[{"role": "system", "content": system_prompt}, {"role": "user", "content": payload.question}],
            max_tokens=MAX_OUTPUT_TOKENS,
            temperature=0.3,
        )
        answer = result.choices[0].message.content
        if not isinstance(answer, str) or not answer.strip():
            raise HTTPException(status_code=502, detail="The AI service returned an empty response. Please try again.")
        return ExplainResponse(explanation=answer.strip(), model=OPENAI_MODEL)
    except HTTPException:
        raise
    except APITimeoutError:
        raise HTTPException(status_code=504, detail="The explanation service timed out. Please try again.")
    except APIConnectionError:
        logger.exception("AI provider connection error")
        raise HTTPException(status_code=502, detail="The explanation service is temporarily unreachable.")
    except APIStatusError as exc:
        logger.error("AI provider status: %s", exc.status_code)
        raise HTTPException(status_code=502, detail="The AI provider could not complete the request. Please try again later.")
    except Exception:
        logger.exception("Unexpected explanation error")
        raise HTTPException(status_code=500, detail="An unexpected server error occurred. Please try again.")
    finally:
        await client.close()
