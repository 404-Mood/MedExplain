# MedExplain backend update

## Included
- `POST /explain` with server-side OpenAI integration.
- Pydantic request/response validation and safe error handling.
- API key read from `OPENAI_API_KEY`, never from frontend code.
- Render Blueprint and `/health` check.

## Apply to GitHub
Replace `main.py` and `requirements.txt`; add `.env.example`, `.gitignore`, and `render.yaml` at the repository root.

## Configure and deploy on Render
1. Open your MedExplain web service.
2. In **Environment**, add `OPENAI_API_KEY` with your own API key.
3. Add `OPENAI_MODEL` = `gpt-4o-mini`.
4. Save, then choose **Manual Deploy → Deploy latest commit**.
5. Check `/health`; it should show `"status":"healthy"` and `"ai_configured":true`.

Never send the API key in ChatGPT, place it in source code, or commit a real `.env`.

## Test
Open `/docs` and send POST `/explain`:
```json
{"question":"What does the medical term hypertension mean?"}
```
Expected fields: `explanation`, `disclaimer`, `model`. Missing key: HTTP 503. Invalid input: HTTP 422.

## Scope
This endpoint explains general medical terms for education. It does not diagnose or analyse uploaded reports. The existing report page only selects files; OCR/PDF extraction is separate work. Test with fictional, non-identifying text only.
